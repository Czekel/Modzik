package com.mediviallike.houses;

import com.mediviallike.houses.block.ModBlocks;
import com.mediviallike.houses.block.entity.ModBlockEntities;
import com.mediviallike.houses.item.ModItems;
import com.mediviallike.houses.schematic.SchematicLoader;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MedievalHousesMod implements ModInitializer {

    public static final String MOD_ID = "medieval_houses";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Medieval Houses: \u0142adowanie systemu budowania dom\u00f3w...");

        SchematicLoader.loadAll();

        ModBlocks.init();
        ModBlockEntities.init();
        ModItems.init();

        LOGGER.info("Medieval Houses: gotowe.");
    }
}
