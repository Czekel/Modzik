package com.mediviallike.houses.schematic;

import java.util.List;
import java.util.Map;

/**
 * Pe\u0142ny opis budynku: jego identyfikator, wymagane materia\u0142y
 * (dok\u0142adnie tyle, ile blok\u00f3w danego typu wyst\u0119puje w li\u015bcie "blocks")
 * oraz lista blok\u00f3w do postawienia wzgl\u0119dem placu budowy.
 */
public class Schematic {
    public String id;
    public String name;
    public Map<String, Integer> materials;
    public List<BlockEntry> blocks;
}
