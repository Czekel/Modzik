package com.mediviallike.houses.block.entity;

import com.mediviallike.houses.MedievalHousesMod;
import com.mediviallike.houses.block.ModBlocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModBlockEntities {

    public static final BlockEntityType<ConstructionSiteBlockEntity> CONSTRUCTION_SITE = Registry.register(
            Registries.BLOCK_ENTITY_TYPE,
            Identifier.of(MedievalHousesMod.MOD_ID, "construction_site"),
            BlockEntityType.Builder.create(ConstructionSiteBlockEntity::new, ModBlocks.CONSTRUCTION_SITE).build()
    );

    private ModBlockEntities() {
    }

    public static void init() {
        // klasa \u0142adowana statycznie przy starcie moda
    }
}
