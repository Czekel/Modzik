package com.mediviallike.houses.schematic;

import net.minecraft.util.math.Direction;

import java.util.HashMap;
import java.util.Map;

/**
 * Obraca pojedynczy wpis schematu (pozycje x/z oraz kierunek "facing"
 * we wlasciwosciach stanu) o 0/90/180/270 stopni wokol punktu (0,0,0)
 * - czyli wokol placu budowy. Uzywane, gdy gracz obroci Blueprint
 * przed postawieniem.
 */
public final class SchematicRotation {

    private SchematicRotation() {
    }

    public static BlockEntry rotate(BlockEntry entry, int steps) {
        int normalizedSteps = ((steps % 4) + 4) % 4;
        if (normalizedSteps == 0) {
            return entry;
        }

        int x = entry.x;
        int z = entry.z;
        for (int i = 0; i < normalizedSteps; i++) {
            int newX = -z;
            int newZ = x;
            x = newX;
            z = newZ;
        }

        BlockEntry rotated = new BlockEntry(x, entry.y, z, entry.block);

        if (entry.state != null) {
            Map<String, String> newState = new HashMap<>();
            for (Map.Entry<String, String> prop : entry.state.entrySet()) {
                if (prop.getKey().equals("facing")) {
                    newState.put("facing", rotateFacing(prop.getValue(), normalizedSteps));
                } else {
                    newState.put(prop.getKey(), prop.getValue());
                }
            }
            rotated.state = newState;
        }

        return rotated;
    }

    private static String rotateFacing(String facing, int steps) {
        Direction dir = switch (facing) {
            case "north" -> Direction.NORTH;
            case "south" -> Direction.SOUTH;
            case "east" -> Direction.EAST;
            case "west" -> Direction.WEST;
            default -> null;
        };
        if (dir == null) {
            return facing;
        }
        for (int i = 0; i < steps; i++) {
            dir = dir.rotateYClockwise();
        }
        return dir.asString();
    }
}
