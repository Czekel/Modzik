package com.mediviallike.houses.schematic;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mediviallike.houses.MedievalHousesMod;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Wczytuje pliki JSON ze schematami budynk\u00f3w, spakowane wewn\u0105trz moda
 * w /schematics/*.json (zasoby na sta\u0142e w jarze, nie datapack).
 *
 * Dodaj tu now\u0105 nazw\u0119 pliku, je\u015bli dorzucisz kolejny budynek.
 */
public final class SchematicLoader {

    private static final Gson GSON = new GsonBuilder().create();
    private static final String[] SCHEMATIC_FILES = {
            "wooden_hut.json",
            "studnia.json",
            "spichlerz.json",
            "chata_mysliwska.json",
            "mala_chata.json",
            "srednia_chata.json",
            "duza_chata.json",
            "stodola.json",
            "kuznia.json",
            "stajnia.json",
            "kurnik.json",
            "chlew.json",
            "pasieka.json",
            "stragan.json",
            "wiatrak.json"
    };

    private static final Map<String, Schematic> SCHEMATICS = new HashMap<>();

    private SchematicLoader() {
    }

    public static void loadAll() {
        for (String fileName : SCHEMATIC_FILES) {
            Schematic schematic = load(fileName);
            if (schematic != null) {
                SCHEMATICS.put(schematic.id, schematic);
                MedievalHousesMod.LOGGER.info("Wczytano schemat budynku: {} ({} blok\u00f3w)",
                        schematic.id, schematic.blocks.size());
            }
        }
    }

    private static Schematic load(String fileName) {
        String path = "/schematics/" + fileName;
        try (InputStream stream = SchematicLoader.class.getResourceAsStream(path)) {
            if (stream == null) {
                MedievalHousesMod.LOGGER.error("Nie znaleziono schematu: {}", path);
                return null;
            }
            try (InputStreamReader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
                return GSON.fromJson(reader, Schematic.class);
            }
        } catch (IOException e) {
            MedievalHousesMod.LOGGER.error("B\u0142\u0105d wczytywania schematu {}", path, e);
            return null;
        }
    }

    public static Schematic get(String id) {
        return SCHEMATICS.get(id);
    }
}
