package com.mediviallike.houses.block.entity;

import com.mediviallike.houses.block.TroughBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Przechowuje jeden stack przedmiotow (pasza/ziarno). Puste rece -
 * wyjmij zawartosc. Trzymasz cos w rece - wsyp. Po kazdej zmianie
 * aktualizuje widoczny stan bloku (filled=true/false).
 */
public class TroughBlockEntity extends BlockEntity {

    private ItemStack storedStack = ItemStack.EMPTY;

    public TroughBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.TROUGH, pos, state);
    }

    public boolean interact(PlayerEntity player, ItemStack heldStack) {
        if (!storedStack.isEmpty()) {
            player.getInventory().offerOrDrop(storedStack.copy());
            storedStack = ItemStack.EMPTY;
            syncFilledState();
            markDirty();
            player.sendMessage(Text.literal("\u00a77Oprozniono koryto."), true);
            return true;
        }
        if (!heldStack.isEmpty()) {
            storedStack = heldStack.copy();
            heldStack.setCount(0);
            syncFilledState();
            markDirty();
            player.sendMessage(Text.literal("\u00a7aWsypano do koryta: " + storedStack.getCount() + "x "
                    + storedStack.getItem().toString()), true);
            return true;
        }
        return false;
    }

    private void syncFilledState() {
        World world = getWorld();
        if (world == null || world.isClient) {
            return;
        }
        BlockState current = getCachedState();
        boolean shouldBeFilled = !storedStack.isEmpty();
        if (current.get(TroughBlock.FILLED) != shouldBeFilled) {
            world.setBlockState(getPos(), current.with(TroughBlock.FILLED, shouldBeFilled));
        }
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.writeNbt(nbt, registryLookup);
        if (!storedStack.isEmpty()) {
            nbt.put("StoredStack", storedStack.encode(registryLookup));
        }
    }

    @Override
    public void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.readNbt(nbt, registryLookup);
        if (nbt.contains("StoredStack")) {
            storedStack = ItemStack.fromNbtOrEmpty(registryLookup, nbt.getCompound("StoredStack"));
        } else {
            storedStack = ItemStack.EMPTY;
        }
    }
}

