package com.mediviallike.houses.block.entity;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

/**
 * Przechowuje jeden stack przedmiotow (pasza/ziarno). Puste rece -
 * wyjmij zawartosc. Trzymasz cos w rece - wsyp.
 */
public class TroughBlockEntity extends BlockEntity {

    private ItemStack storedStack = ItemStack.EMPTY;

    public TroughBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.TROUGH, pos, state);
    }

    public boolean interact(PlayerEntity player, ItemStack heldStack) {
        if (!storedStack.isEmpty()) {
            player.getInventory().offerOrDrop(storedStack.copy());
            storedStack = ItemStack.EMPTY;
            markDirty();
            player.sendMessage(Text.literal("\u00a77Oprozniono koryto."), true);
            return true;
        }
        if (!heldStack.isEmpty()) {
            storedStack = heldStack.copy();
            heldStack.setCount(0);
            markDirty();
            player.sendMessage(Text.literal("\u00a7aWsypano do koryta: " + storedStack.getCount() + "x "
                    + storedStack.getItem().toString()), true);
            return true;
        }
        return false;
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.writeNbt(nbt, registryLookup);
        if (!storedStack.isEmpty()) {
            nbt.put("StoredStack", storedStack.encode(registryLookup));
        }
    }

    @Override
    public void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.readNbt(nbt, registryLookup);
        if (nbt.contains("StoredStack")) {
            storedStack = ItemStack.fromNbtOrEmpty(registryLookup, nbt.getCompound("StoredStack"));
        } else {
            storedStack = ItemStack.EMPTY;
        }
    }
}
