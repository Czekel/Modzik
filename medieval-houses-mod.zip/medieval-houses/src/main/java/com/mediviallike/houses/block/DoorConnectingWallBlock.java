package com.mediviallike.houses.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.WallBlock;
import net.minecraft.util.math.Direction;

/**
 * Murek dzialajacy jak wanilijny "wall" (np. cobblestone_wall) - laczy
 * sie wizualnie z sasiednimi PELNYMI blokami tak jak zwykly murek.
 * Dodatkowo: laczy sie takze z drzwiami (DoorBlock), czego zwykly
 * wanilijny murek nie robi domyslnie.
 *
 * Uzywana zarowno dla "murka z desek" jak i dla "malej klody" - obie
 * roznia sie tylko tekstura/modelem, nie logika.
 */
public class DoorConnectingWallBlock extends WallBlock {

    public DoorConnectingWallBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected boolean canConnect(BlockState state, boolean sideSolidFullSquare, Direction direction) {
        if (state.getBlock() instanceof DoorBlock) {
            return true;
        }
        return super.canConnect(state, sideSolidFullSquare, direction);
    }
}
