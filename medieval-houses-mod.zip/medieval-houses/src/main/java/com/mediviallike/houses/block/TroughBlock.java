package com.mediviallike.houses.block;

import com.mediviallike.houses.block.entity.ModBlockEntities;
import com.mediviallike.houses.block.entity.TroughBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Koryto - wsypujesz do niego pasze/ziarno (trzymajac je w rece i
 * klikajac PPM), a puste rece PPM je oprozniaja z powrotem do ekwipunku.
 *
 * WAZNE: to jest TYLKO magazynek. Nie ma tu podpietej logiki zwierzat
 * (kury chodzace jesc/znosic jajka) - to osobny, znacznie wiekszy temat
 * (wlasna AI stworzen), do zrobienia pozniej jesli bedzie taka potrzeba.
 */
public class TroughBlock extends BlockWithEntity {

    public static final MapCodec<TroughBlock> CODEC = createCodec(TroughBlock::new);
    private static final net.minecraft.util.math.VoxelShape SHAPE =
            net.minecraft.block.Block.createCuboidShape(3, 0, 0, 13, 6, 16);

    public TroughBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected net.minecraft.util.math.VoxelShape getOutlineShape(BlockState state, net.minecraft.world.BlockView world,
                                                                    BlockPos pos, net.minecraft.block.ShapeContext context) {
        return SHAPE;
    }

    @Override
    protected net.minecraft.util.math.VoxelShape getCollisionShape(BlockState state, net.minecraft.world.BlockView world,
                                                                      BlockPos pos, net.minecraft.block.ShapeContext context) {
        return SHAPE;
    }

    @Override
    protected MapCodec<? extends BlockWithEntity> getCodec() {
        return CODEC;
    }

    @Override
    protected BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new TroughBlockEntity(pos, state);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world.isClient) {
            return ActionResult.SUCCESS;
        }
        BlockEntity be = world.getBlockEntity(pos);
        if (be instanceof TroughBlockEntity trough) {
            ItemStack heldStack = player.getStackInHand(Hand.MAIN_HAND);
            boolean handled = trough.interact(player, heldStack);
            return handled ? ActionResult.SUCCESS : ActionResult.PASS;
        }
        return ActionResult.PASS;
    }
}
