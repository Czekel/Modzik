package com.mediviallike.houses.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.VoxelShape;
import net.minecraft.world.BlockView;

/**
 * Murek z desek - w odroznieniu od zwyklego "wall" z Minecrafta NIE ma
 * grubszych zakonczen/postumentow - to po prostu cienka, jednolita
 * plyta na cala wysokosc bloku. Nie ma tez inteligentnego "laczenia sie"
 * jak plot z bramka (to bylby duzo wiekszy, osobny temat) - ale dzieki
 * pelnej wysokosci naturalnie rowna sie z futryna drzwi.
 */
public class PlankRailingBlock extends Block {

    private static final VoxelShape SHAPE = Block.createCuboidShape(6, 0, 6, 10, 16, 10);

    public PlankRailingBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return SHAPE;
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return SHAPE;
    }
}
