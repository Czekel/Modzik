package com.mediviallike.houses.item;

import com.mediviallike.houses.block.ModBlocks;
import com.mediviallike.houses.block.StrawBedBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.enums.BedPart;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

/**
 * Stawia slomiane poslanie jako DWA bloki naraz (stopa + wezglowie),
 * tak jak normalne lozko - w kierunku, w ktorym gracz patrzy.
 */
public class StrawBedItem extends Item {

    public StrawBedItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        PlayerEntity player = context.getPlayer();
        if (player == null) {
            return ActionResult.FAIL;
        }

        BlockPos clickedPos = context.getBlockPos();
        Direction side = context.getSide();
        BlockPos footPos = side == Direction.UP ? clickedPos.up() : clickedPos.offset(side);

        Direction facing = player.getHorizontalFacing();
        BlockPos headPos = footPos.offset(facing);

        if (!world.getBlockState(footPos).isAir() || !world.getBlockState(headPos).isAir()) {
            player.sendMessage(Text.literal("\u00a7cZa malo miejsca na poslanie (potrzeba 2 wolnych blokow)."), true);
            return ActionResult.FAIL;
        }

        if (world.isClient) {
            return ActionResult.SUCCESS;
        }

        BlockState footState = ModBlocks.STRAW_BED.getDefaultState()
                .with(StrawBedBlock.FACING, facing)
                .with(StrawBedBlock.PART, BedPart.FOOT);
        BlockState headState = ModBlocks.STRAW_BED.getDefaultState()
                .with(StrawBedBlock.FACING, facing)
                .with(StrawBedBlock.PART, BedPart.HEAD);

        world.setBlockState(footPos, footState);
        world.setBlockState(headPos, headState);

        if (!player.isCreative()) {
            context.getStack().decrement(1);
        }
        return ActionResult.SUCCESS;
    }
}
