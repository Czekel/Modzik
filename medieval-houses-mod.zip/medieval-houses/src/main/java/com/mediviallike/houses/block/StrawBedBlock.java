package com.mediviallike.houses.block;

import net.minecraft.block.BedBlock;
import net.minecraft.util.DyeColor;

/**
 * "Slomiane" lozko - niezniszczalne (strength -1, ogromna odpornosc na
 * wybuchy - jak bedrock). Wizualnie reuzywa wanilijnej tekstury zoltego
 * lozka (najblizszej kolorystycznie sianu/slomie) - w pelni unikalna
 * tekstura lozka wymagalaby wlasnego renderera 3D (osobny, duzo wiekszy
 * temat), wiec to uproszczenie na teraz.
 */
public class StrawBedBlock extends BedBlock {

    public StrawBedBlock(Settings settings) {
        super(DyeColor.YELLOW, settings);
    }
}
