package com.mediviallike.houses.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/**
 * Slomiane poslanie - TRWALE (nie znika po jednym uzyciu, nie da sie go
 * zniszczyc - patrz strength w ModBlocks). W odroznieniu od prawdziwego
 * wanilijnego lozka Minecrafta NIE ma animacji lezenia/spania ani nie
 * ustawia punktu odrodzenia - to zwykly blok. Klikniete noca (albo w
 * czasie burzy) przewija czas do rana i czysci pogode, dajac ten sam
 * praktyczny efekt co spanie.
 *
 * Celowo NIE jest podklasa wanilijnego BedBlock - ten wymaga zarejestrowania
 * bloku na sztywno zaszytej liscie w silniku gry (stad crash przy
 * poprzedniej probie), a to omijamy uzywajac zwyklego bloku.
 */
public class StrawBedBlock extends Block {

    private static final VoxelShape SHAPE = Block.createCuboidShape(0, 0, 0, 16, 8, 16);

    public StrawBedBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return SHAPE;
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world.isClient) {
            return ActionResult.SUCCESS;
        }
        long time = world.getTimeOfDay() % 24000L;
        boolean isNight = time >= 12542L && time <= 23458L;
        boolean isThundering = world instanceof ServerWorld serverWorld && serverWorld.isThundering();

        if (isNight || isThundering) {
            if (world instanceof ServerWorld serverWorld) {
                serverWorld.setTimeOfDay(world.getTimeOfDay() + (24000L - time));
                serverWorld.setWeather(12000, 0, false, false);
            }
            player.sendMessage(Text.literal("\u00a7aPrzespales noc na slomianym poslaniu."), true);
            return ActionResult.SUCCESS;
        }
        player.sendMessage(Text.literal("\u00a77Mozesz na nim spac tylko noca albo w czasie burzy."), true);
        return ActionResult.PASS;
    }
}
