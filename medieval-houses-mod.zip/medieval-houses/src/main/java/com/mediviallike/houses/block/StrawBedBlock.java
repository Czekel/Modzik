package com.mediviallike.houses.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.enums.BedPart;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/**
 * Slomiane poslanie - TRWALE (nie znika po jednym uzyciu, nie da sie go
 * zniszczyc - patrz strength w ModBlocks). Zajmuje 2 bloki (stopa + wezglowie)
 * jak normalne lozko, ale to NIE jest podklasa wanilijnego BedBlock (ten
 * wymaga zarejestrowania na sztywno zaszytej liscie w silniku gry, co
 * powodowalo crash przy wczesniejszej probie) - to zwykly blok z 2 czesciami,
 * stawiany przez StrawBedItem. Brak animacji lezenia/spania ani punktu
 * odrodzenia - klikniete noca (albo w czasie burzy) przewija czas do rana.
 */
public class StrawBedBlock extends Block {

    public static final EnumProperty<BedPart> PART = Properties.BED_PART;
    public static final DirectionProperty FACING = Properties.HORIZONTAL_FACING;

    private static final VoxelShape SHAPE = Block.createCuboidShape(0, 0, 0, 16, 6, 16);

    public StrawBedBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(PART, BedPart.FOOT).with(FACING, Direction.NORTH));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(PART, FACING);
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return SHAPE;
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world.isClient) {
            return ActionResult.SUCCESS;
        }
        long time = world.getTimeOfDay() % 24000L;
        boolean isNight = time >= 12542L && time <= 23458L;
        boolean isThundering = world instanceof ServerWorld serverWorld && serverWorld.isThundering();

        if (isNight || isThundering) {
            if (world instanceof ServerWorld serverWorld) {
                serverWorld.setTimeOfDay(world.getTimeOfDay() + (24000L - time));
                serverWorld.setWeather(12000, 0, false, false);
            }
            player.sendMessage(Text.literal("\u00a7aPrzespales noc na slomianym poslaniu."), true);
            return ActionResult.SUCCESS;
        }
        player.sendMessage(Text.literal("\u00a77Mozesz na nim spac tylko noca albo w czasie burzy."), true);
        return ActionResult.PASS;
    }
}
