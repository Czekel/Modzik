package com.mediviallike.houses.block;

import com.mediviallike.houses.MedievalHousesMod;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.MapColor;
import net.minecraft.block.StairsBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModBlocks {

    public static final Block CONSTRUCTION_SITE = register(
            "construction_site",
            settings -> new ConstructionSiteBlock(settings),
            AbstractBlock.Settings.create()
                    .mapColor(MapColor.PALE_YELLOW)
                    .strength(0.5f)
                    .nonOpaque()
                    .noCollision()
    );

    public static final Block SMALL_LOG = register(
            "small_log",
            settings -> new SmallLogBlock(settings),
            AbstractBlock.Settings.copy(Blocks.OAK_LOG)
    );

    public static final Block STRAW_STAIRS = register(
            "straw_stairs",
            settings -> new StairsBlock(Blocks.HAY_BLOCK.getDefaultState(), settings),
            AbstractBlock.Settings.copy(Blocks.HAY_BLOCK)
    );

    public static final Block PLANK_RAILING = register(
            "plank_railing",
            settings -> new PlankRailingBlock(settings),
            AbstractBlock.Settings.copy(Blocks.OAK_PLANKS)
    );

    public static final Block TROUGH = register(
            "trough",
            settings -> new TroughBlock(settings),
            AbstractBlock.Settings.create()
                    .mapColor(MapColor.OAK_TAN)
                    .strength(2.0f)
                    .nonOpaque()
    );

    public static final Item SMALL_LOG_ITEM;
    public static final Item STRAW_STAIRS_ITEM;
    public static final Item PLANK_RAILING_ITEM;
    public static final Item TROUGH_ITEM;

    static {
        SMALL_LOG_ITEM = registerBlockItem("small_log", SMALL_LOG);
        STRAW_STAIRS_ITEM = registerBlockItem("straw_stairs", STRAW_STAIRS);
        PLANK_RAILING_ITEM = registerBlockItem("plank_railing", PLANK_RAILING);
        TROUGH_ITEM = registerBlockItem("trough", TROUGH);
    }

    private ModBlocks() {
    }

    private static Block register(String path, java.util.function.Function<AbstractBlock.Settings, Block> factory,
                                    AbstractBlock.Settings settings) {
        Identifier id = Identifier.of(MedievalHousesMod.MOD_ID, path);
        Block block = factory.apply(settings);
        return Registry.register(Registries.BLOCK, id, block);
    }

    private static Item registerBlockItem(String path, Block block) {
        Identifier id = Identifier.of(MedievalHousesMod.MOD_ID, path);
        Item item = new BlockItem(block, new Item.Settings());
        return Registry.register(Registries.ITEM, id, item);
    }

    public static void init() {
        // klasa ladowana statycznie - rejestracja juz sie odbyla w polach powyzej
    }
}
