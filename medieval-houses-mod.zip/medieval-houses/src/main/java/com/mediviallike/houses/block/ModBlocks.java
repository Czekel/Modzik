package com.mediviallike.houses.block;

import com.mediviallike.houses.MedievalHousesMod;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModBlocks {

    public static final Block CONSTRUCTION_SITE = register(
            "construction_site",
            settings -> new ConstructionSiteBlock(settings),
            AbstractBlock.Settings.create()
                    .mapColor(MapColor.PALE_YELLOW)
                    .strength(0.5f)
                    .nonOpaque()
                    .noCollision()
    );

    private ModBlocks() {
    }

    private static Block register(String path, java.util.function.Function<AbstractBlock.Settings, Block> factory,
                                    AbstractBlock.Settings settings) {
        Identifier id = Identifier.of(MedievalHousesMod.MOD_ID, path);
        Block block = factory.apply(settings.registryKey(net.minecraft.registry.RegistryKey.of(net.minecraft.registry.RegistryKeys.BLOCK, id)));
        return Registry.register(Registries.BLOCK, id, block);
    }

    public static void init() {
        // klasa \u0142adowana statycznie przy starcie moda - patrz MedievalHousesMod
    }
}
