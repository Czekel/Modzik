package com.mediviallike.houses.schematic;

/**
 * Jedna pozycja bloku wewn\u0105trz schematu budynku, wsp\u00f3\u0142rz\u0119dne
 * s\u0105 wzgl\u0119dne wobec bloku "Placu budowy" (0,0,0).
 */
public class BlockEntry {
    public int x;
    public int y;
    public int z;
    public String block;

    public BlockEntry() {
    }

    public BlockEntry(int x, int y, int z, String block) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.block = block;
    }
}
