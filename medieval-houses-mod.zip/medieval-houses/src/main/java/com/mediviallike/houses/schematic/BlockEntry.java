package com.mediviallike.houses.schematic;

import java.util.Map;

/**
 * Jedna pozycja bloku wewnatrz schematu budynku, wspolrzedne
 * sa wzgledne wobec bloku "Placu budowy" (0,0,0).
 *
 * "state" to opcjonalna mapa wlasciwosci blockstate (np. facing, half)
 * - przydatne dla schodow, drzwi itp. Jesli puste, uzywany jest
 * domyslny stan bloku.
 */
public class BlockEntry {
    public int x;
    public int y;
    public int z;
    public String block;
    public Map<String, String> state;

    public BlockEntry() {
    }

    public BlockEntry(int x, int y, int z, String block) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.block = block;
    }
}
