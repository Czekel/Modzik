package com.mediviallike.houses.item;

import com.mediviallike.houses.MedievalHousesMod;
import com.mediviallike.houses.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItems {

    public static final RegistryKey<ItemGroup> GROUP_KEY = RegistryKey.of(
            RegistryKeys.ITEM_GROUP, Identifier.of(MedievalHousesMod.MOD_ID, "main"));

    public static final Item BLUEPRINT_MALA_CHATA = register(
            "blueprint_mala_chata",
            settings -> new BlueprintItem(settings, "mala_chata"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_SREDNIA_CHATA = register(
            "blueprint_srednia_chata",
            settings -> new BlueprintItem(settings, "srednia_chata"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_DUZA_CHATA = register(
            "blueprint_duza_chata",
            settings -> new BlueprintItem(settings, "duza_chata"),
            new Item.Settings().maxCount(1)
    );

    private ModItems() {
    }

    private static Item register(String path, java.util.function.Function<Item.Settings, Item> factory,
                                   Item.Settings settings) {
        Identifier id = Identifier.of(MedievalHousesMod.MOD_ID, path);
        Item item = factory.apply(settings);
        return Registry.register(Registries.ITEM, id, item);
    }

    public static void init() {
        ItemGroup group = FabricItemGroup.builder()
                .icon(() -> new ItemStack(BLUEPRINT_MALA_CHATA))
                .displayName(Text.literal("Medieval Houses"))
                .build();
        Registry.register(Registries.ITEM_GROUP, GROUP_KEY, group);

        ItemGroupEvents.modifyEntriesEvent(GROUP_KEY).register(entries -> {
            entries.add(BLUEPRINT_MALA_CHATA);
            entries.add(BLUEPRINT_SREDNIA_CHATA);
            entries.add(BLUEPRINT_DUZA_CHATA);
            entries.add(ModBlocks.SMALL_LOG_ITEM);
            entries.add(ModBlocks.STRAW_STAIRS_ITEM);
            entries.add(ModBlocks.PLANK_RAILING_ITEM);
            entries.add(ModBlocks.STONE_RAILING_ITEM);
            entries.add(ModBlocks.TROUGH_ITEM);
            entries.add(ModBlocks.STRAW_BED_ITEM);
        });
    }
}
