package com.mediviallike.houses.item;

import com.mediviallike.houses.MedievalHousesMod;
import com.mediviallike.houses.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItems {

    public static final RegistryKey<ItemGroup> GROUP_KEY = RegistryKey.of(
            RegistryKeys.ITEM_GROUP, Identifier.of(MedievalHousesMod.MOD_ID, "main"));

    public static final Item BLUEPRINT_WOODEN_HUT = register(
            "blueprint_wooden_hut",
            settings -> new BlueprintItem(settings, "wooden_hut"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_STUDNIA = register(
            "blueprint_studnia",
            settings -> new BlueprintItem(settings, "studnia"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_SPICHLERZ = register(
            "blueprint_spichlerz",
            settings -> new BlueprintItem(settings, "spichlerz"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_CHATA_MYSLIWSKA = register(
            "blueprint_chata_mysliwska",
            settings -> new BlueprintItem(settings, "chata_mysliwska"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_MALA_CHATA = register(
            "blueprint_mala_chata",
            settings -> new BlueprintItem(settings, "mala_chata"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_SREDNIA_CHATA = register(
            "blueprint_srednia_chata",
            settings -> new BlueprintItem(settings, "srednia_chata"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_DUZA_CHATA = register(
            "blueprint_duza_chata",
            settings -> new BlueprintItem(settings, "duza_chata"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_STODOLA = register(
            "blueprint_stodola",
            settings -> new BlueprintItem(settings, "stodola"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_KUZNIA = register(
            "blueprint_kuznia",
            settings -> new BlueprintItem(settings, "kuznia"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_STAJNIA = register(
            "blueprint_stajnia",
            settings -> new BlueprintItem(settings, "stajnia"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_KURNIK = register(
            "blueprint_kurnik",
            settings -> new BlueprintItem(settings, "kurnik"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_CHLEW = register(
            "blueprint_chlew",
            settings -> new BlueprintItem(settings, "chlew"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_PASIEKA = register(
            "blueprint_pasieka",
            settings -> new BlueprintItem(settings, "pasieka"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_STRAGAN = register(
            "blueprint_stragan",
            settings -> new BlueprintItem(settings, "stragan"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_WIATRAK = register(
            "blueprint_wiatrak",
            settings -> new BlueprintItem(settings, "wiatrak"),
            new Item.Settings().maxCount(1)
    );

    private ModItems() {
    }

    private static Item register(String path, java.util.function.Function<Item.Settings, Item> factory,
                                   Item.Settings settings) {
        Identifier id = Identifier.of(MedievalHousesMod.MOD_ID, path);
        Item item = factory.apply(settings);
        return Registry.register(Registries.ITEM, id, item);
    }

    public static void init() {
        ItemGroup group = FabricItemGroup.builder()
                .icon(() -> new ItemStack(BLUEPRINT_WOODEN_HUT))
                .displayName(Text.literal("Medieval Houses"))
                .build();
        Registry.register(Registries.ITEM_GROUP, GROUP_KEY, group);

        ItemGroupEvents.modifyEntriesEvent(GROUP_KEY).register(entries -> {
            entries.add(BLUEPRINT_WOODEN_HUT);
            entries.add(BLUEPRINT_STUDNIA);
            entries.add(BLUEPRINT_SPICHLERZ);
            entries.add(BLUEPRINT_CHATA_MYSLIWSKA);
            entries.add(BLUEPRINT_MALA_CHATA);
            entries.add(BLUEPRINT_SREDNIA_CHATA);
            entries.add(BLUEPRINT_DUZA_CHATA);
            entries.add(BLUEPRINT_STODOLA);
            entries.add(BLUEPRINT_KUZNIA);
            entries.add(BLUEPRINT_STAJNIA);
            entries.add(BLUEPRINT_KURNIK);
            entries.add(BLUEPRINT_CHLEW);
            entries.add(BLUEPRINT_PASIEKA);
            entries.add(BLUEPRINT_STRAGAN);
            entries.add(BLUEPRINT_WIATRAK);
            entries.add(ModBlocks.SMALL_LOG_ITEM);
            entries.add(ModBlocks.STRAW_STAIRS_ITEM);
            entries.add(ModBlocks.PLANK_RAILING_ITEM);
            entries.add(ModBlocks.STONE_RAILING_ITEM);
            entries.add(ModBlocks.TROUGH_ITEM);
            entries.add(ModBlocks.STRAW_BED_ITEM);
        });
    }
}
