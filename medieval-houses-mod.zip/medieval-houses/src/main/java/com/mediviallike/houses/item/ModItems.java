package com.mediviallike.houses.item;

import com.mediviallike.houses.MedievalHousesMod;
import com.mediviallike.houses.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItems {

    public static final RegistryKey<ItemGroup> GROUP_KEY = RegistryKey.of(
            RegistryKeys.ITEM_GROUP, Identifier.of(MedievalHousesMod.MOD_ID, "main"));

    public static final Item BLUEPRINT_WOODEN_HUT = register(
            "blueprint_wooden_hut",
            settings -> new BlueprintItem(settings, "wooden_hut"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_STUDNIA = register(
            "blueprint_studnia",
            settings -> new BlueprintItem(settings, "studnia"),
            new Item.Settings().maxCount(1)
    );

    public static final Item BLUEPRINT_SPICHLERZ = register(
            "blueprint_spichlerz",
            settings -> new BlueprintItem(settings, "spichlerz"),
            new Item.Settings().maxCount(1)
    );

    private ModItems() {
    }

    private static Item register(String path, java.util.function.Function<Item.Settings, Item> factory,
                                   Item.Settings settings) {
        Identifier id = Identifier.of(MedievalHousesMod.MOD_ID, path);
        Item item = factory.apply(settings);
        return Registry.register(Registries.ITEM, id, item);
    }

    public static void init() {
        ItemGroup group = FabricItemGroup.builder()
                .icon(() -> new ItemStack(BLUEPRINT_WOODEN_HUT))
                .displayName(Text.literal("Medieval Houses"))
                .build();
        Registry.register(Registries.ITEM_GROUP, GROUP_KEY, group);

        ItemGroupEvents.modifyEntriesEvent(GROUP_KEY).register(entries -> {
            entries.add(BLUEPRINT_WOODEN_HUT);
            entries.add(BLUEPRINT_STUDNIA);
            entries.add(BLUEPRINT_SPICHLERZ);
            entries.add(ModBlocks.SMALL_LOG_ITEM);
            entries.add(ModBlocks.STRAW_STAIRS_ITEM);
            entries.add(ModBlocks.PLANK_RAILING_ITEM);
            entries.add(ModBlocks.TROUGH_ITEM);
        });
    }
}
