package com.mediviallike.houses.item;

import com.mediviallike.houses.block.ModBlocks;
import com.mediviallike.houses.block.entity.ConstructionSiteBlockEntity;
import com.mediviallike.houses.schematic.Schematic;
import com.mediviallike.houses.schematic.SchematicLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

/**
 * Plan budowy - dzia\u0142a jak w Medieval Dynasty: klikasz PPM na ziemi\u0119,
 * a w tym miejscu powstaje "Plac budowy" gotowy na przyjmowanie materia\u0142\u00f3w.
 */
public class BlueprintItem extends Item {

    private final String schematicId;

    public BlueprintItem(Settings settings, String schematicId) {
        super(settings);
        this.schematicId = schematicId;
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos clickedPos = context.getBlockPos();
        Direction side = context.getSide();
        BlockPos placePos = side == Direction.UP ? clickedPos.up() : clickedPos.offset(side);

        if (!world.getBlockState(placePos).isAir()) {
            if (context.getPlayer() != null) {
                context.getPlayer().sendMessage(
                        Text.literal("\u00a7cTu nie ma miejsca na plac budowy."), true);
            }
            return ActionResult.FAIL;
        }

        Schematic schematic = SchematicLoader.get(schematicId);
        if (schematic == null) {
            return ActionResult.FAIL;
        }

        if (world.isClient) {
            return ActionResult.SUCCESS;
        }

        BlockState siteState = ModBlocks.CONSTRUCTION_SITE.getDefaultState();
        world.setBlockState(placePos, siteState);
        BlockEntity be = world.getBlockEntity(placePos);
        if (be instanceof ConstructionSiteBlockEntity site) {
            site.setSchematic(schematicId);
        }

        if (context.getPlayer() != null) {
            context.getPlayer().sendMessage(
                    Text.literal("\u00a7aPlac budowy za\u0142o\u017cony: " + schematic.name
                            + ". Donie\u015b wymagane materia\u0142y i kliknij PPM na plac."), false);
            if (!context.getPlayer().isCreative()) {
                context.getStack().decrement(1);
            }
        }

        return ActionResult.SUCCESS;
    }
}
