package com.mediviallike.houses.item;

import com.mediviallike.houses.block.ModBlocks;
import com.mediviallike.houses.block.entity.ConstructionSiteBlockEntity;
import com.mediviallike.houses.schematic.Schematic;
import com.mediviallike.houses.schematic.SchematicLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

/**
 * Plan budowy - klikasz PPM na ziemie, a w tym miejscu powstaje "Plac
 * budowy". Shift + PPM w powietrzu (bez celowania w blok) obraca plan
 * o 90 stopni przed postawieniem.
 */
public class BlueprintItem extends Item {

    private static final String ROTATION_KEY = "MedievalHousesRotation";

    private final String schematicId;

    public BlueprintItem(Settings settings, String schematicId) {
        super(settings);
        this.schematicId = schematicId;
    }

    public String getSchematicId() {
        return schematicId;
    }

    public static int getRotation(ItemStack stack) {
        NbtComponent component = stack.getOrDefault(DataComponentTypes.CUSTOM_DATA, NbtComponent.DEFAULT);
        return component.copyNbt().getInt(ROTATION_KEY);
    }

    private static void cycleRotation(ItemStack stack, PlayerEntity player) {
        NbtComponent component = stack.getOrDefault(DataComponentTypes.CUSTOM_DATA, NbtComponent.DEFAULT);
        NbtCompound nbt = component.copyNbt();
        int next = (nbt.getInt(ROTATION_KEY) + 1) % 4;
        nbt.putInt(ROTATION_KEY, next);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        player.sendMessage(Text.literal("\u00a7bObrot planu: " + (next * 90) + "\u00b0"), true);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (player.isSneaking()) {
            if (!world.isClient) {
                cycleRotation(stack, player);
            }
            return TypedActionResult.success(stack, world.isClient);
        }
        return TypedActionResult.pass(stack);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos clickedPos = context.getBlockPos();
        Direction side = context.getSide();
        BlockPos placePos = side == Direction.UP ? clickedPos.up() : clickedPos.offset(side);

        if (!world.getBlockState(placePos).isAir()) {
            if (context.getPlayer() != null) {
                context.getPlayer().sendMessage(
                        Text.literal("\u00a7cTu nie ma miejsca na plac budowy."), true);
            }
            return ActionResult.FAIL;
        }

        Schematic schematic = SchematicLoader.get(schematicId);
        if (schematic == null) {
            return ActionResult.FAIL;
        }

        if (world.isClient) {
            return ActionResult.SUCCESS;
        }

        int rotation = getRotation(context.getStack());

        BlockState siteState = ModBlocks.CONSTRUCTION_SITE.getDefaultState();
        world.setBlockState(placePos, siteState);
        BlockEntity be = world.getBlockEntity(placePos);
        if (be instanceof ConstructionSiteBlockEntity site) {
            site.setSchematic(schematicId, rotation);
        }

        if (context.getPlayer() != null) {
            context.getPlayer().sendMessage(
                    Text.literal("\u00a7aPlac budowy zalozony: " + schematic.name
                            + " (obrot " + (rotation * 90) + "\u00b0). Doniesz wymagane materialy i kliknij PPM na plac."), false);
            if (!context.getPlayer().isCreative()) {
                context.getStack().decrement(1);
            }
        }

        return ActionResult.SUCCESS;
    }
}
