package com.mediviallike.houses.block;

import com.mediviallike.houses.block.entity.ConstructionSiteBlockEntity;
import com.mediviallike.houses.block.entity.ModBlockEntities;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Blok, na kt\u00f3rym stoi rozpocz\u0119ta budowa. Gracz podchodzi z materia\u0142em
 * w r\u0119ce i klika PPM, aby go zdeponowa\u0107. Gdy wszystkie materia\u0142y s\u0105
 * skompletowane, blok zaczyna stawia\u0107 kolejne elementy budynku co kilka
 * ticków, a na ko\u0144cu sam znika (zast\u0105piony przez pod\u0142og\u0119 domu).
 */
public class ConstructionSiteBlock extends BlockWithEntity {

    public ConstructionSiteBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new ConstructionSiteBlockEntity(pos, state);
    }

    @Nullable
    @Override
    protected <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
        return validateTicker(type, ModBlockEntities.CONSTRUCTION_SITE,
                ConstructionSiteBlockEntity::serverTick);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world.isClient) {
            return ActionResult.SUCCESS;
        }
        BlockEntity be = world.getBlockEntity(pos);
        if (be instanceof ConstructionSiteBlockEntity site) {
            ItemStack heldStack = player.getStackInHand(Hand.MAIN_HAND);
            boolean deposited = site.tryDeposit(player, heldStack);
            return deposited ? ActionResult.SUCCESS : ActionResult.CONSUME;
        }
        return ActionResult.PASS;
    }
}
