package com.mediviallike.houses.block;

import com.mediviallike.houses.block.entity.ConstructionSiteBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Blok, na ktorym stoi rozpoczeta budowa. Gracz najpierw donosi
 * materialy (klika PPM trzymajac je w rece), a gdy sa skompletowane,
 * kazde kolejne klikniecie PPM stawia dokladnie jeden kolejny blok
 * budynku - az do ukonczenia.
 */
public class ConstructionSiteBlock extends BlockWithEntity {

    public static final MapCodec<ConstructionSiteBlock> CODEC = createCodec(ConstructionSiteBlock::new);

    public ConstructionSiteBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends BlockWithEntity> getCodec() {
        return CODEC;
    }

    @Override
    protected BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new ConstructionSiteBlockEntity(pos, state);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world.isClient) {
            return ActionResult.SUCCESS;
        }
        BlockEntity be = world.getBlockEntity(pos);
        if (be instanceof ConstructionSiteBlockEntity site) {
            if (site.isBuilding()) {
                boolean placed = site.advanceBuild(world, pos, player);
                return placed ? ActionResult.SUCCESS : ActionResult.PASS;
            }
            ItemStack heldStack = player.getStackInHand(Hand.MAIN_HAND);
            boolean deposited = site.tryDeposit(player, heldStack);
            return deposited ? ActionResult.SUCCESS : ActionResult.CONSUME;
        }
        return ActionResult.PASS;
    }
}
