package com.mediviallike.houses;

import com.mediviallike.houses.item.BlueprintItem;
import com.mediviallike.houses.schematic.BlockEntry;
import com.mediviallike.houses.schematic.Schematic;
import com.mediviallike.houses.schematic.SchematicLoader;
import com.mediviallike.houses.schematic.SchematicRotation;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.HashSet;
import java.util.Set;

/**
 * Renderuje "hologram" - widmowy ZARYS BRYLY budynku (nie siatke
 * pojedynczych kratek) przed postawieniem placu budowy. Rysuje tylko
 * krawedzie scian, ktore sa "na zewnatrz" calej budowli (czyli tam,
 * gdzie w schemacie nie ma sasiedniego bloku) - dzieki temu widac
 * faktyczny ksztalt konstrukcji, a nie osobny szescian na kazdy blok.
 *
 * Uwaga: to jest kod dzialajacy tylko po stronie klienta (rysowanie),
 * nie zmienia niczego w swiecie gry.
 */
public class MedievalHousesClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::renderGhostPreview);
    }

    private void renderGhostPreview(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }

        ItemStack mainHand = client.player.getStackInHand(Hand.MAIN_HAND);
        if (!(mainHand.getItem() instanceof BlueprintItem blueprintItem)) {
            return;
        }

        if (!(client.crosshairTarget instanceof BlockHitResult hitResult)) {
            return;
        }

        BlockPos clickedPos = hitResult.getBlockPos();
        Direction side = hitResult.getSide();
        BlockPos placePos = side == Direction.UP ? clickedPos.up() : clickedPos.offset(side);

        Schematic schematic = SchematicLoader.get(blueprintItem.getSchematicId());
        if (schematic == null) {
            return;
        }

        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        if (matrices == null || consumers == null) {
            return;
        }
        Vec3d camera = context.camera().getPos();
        VertexConsumer buffer = consumers.getBuffer(RenderLayer.getLines());

        int rotation = BlueprintItem.getRotation(mainHand);

        // Zbior zajetych pozycji wzglednych (po obrocie) - do sprawdzania
        // sasiadow, zeby wiedziec ktore sciany sa "na zewnatrz".
        Set<BlockPos> occupied = new HashSet<>();
        for (BlockEntry rawEntry : schematic.blocks) {
            BlockEntry entry = SchematicRotation.rotate(rawEntry, rotation);
            occupied.add(new BlockPos(entry.x, entry.y, entry.z));
        }

        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        float r = 0.3f, g = 0.75f, b = 1.0f, a = 0.85f;

        for (BlockPos rel : occupied) {
            double bx = placePos.getX() + rel.getX();
            double by = placePos.getY() + rel.getY();
            double bz = placePos.getZ() + rel.getZ();

            if (!occupied.contains(rel.down())) {
                faceOutline(buffer, matrix, r, g, b, a,
                        bx, by, bz, bx + 1, by, bz, bx + 1, by, bz + 1, bx, by, bz + 1);
            }
            if (!occupied.contains(rel.up())) {
                faceOutline(buffer, matrix, r, g, b, a,
                        bx, by + 1, bz, bx, by + 1, bz + 1, bx + 1, by + 1, bz + 1, bx + 1, by + 1, bz);
            }
            if (!occupied.contains(rel.north())) {
                faceOutline(buffer, matrix, r, g, b, a,
                        bx, by, bz, bx, by + 1, bz, bx + 1, by + 1, bz, bx + 1, by, bz);
            }
            if (!occupied.contains(rel.south())) {
                faceOutline(buffer, matrix, r, g, b, a,
                        bx, by, bz + 1, bx + 1, by, bz + 1, bx + 1, by + 1, bz + 1, bx, by + 1, bz + 1);
            }
            if (!occupied.contains(rel.west())) {
                faceOutline(buffer, matrix, r, g, b, a,
                        bx, by, bz, bx, by, bz + 1, bx, by + 1, bz + 1, bx, by + 1, bz);
            }
            if (!occupied.contains(rel.east())) {
                faceOutline(buffer, matrix, r, g, b, a,
                        bx + 1, by, bz, bx + 1, by + 1, bz, bx + 1, by + 1, bz + 1, bx + 1, by, bz + 1);
            }
        }

        matrices.pop();
    }

    /** Rysuje 4 krawedzie (obrys) jednej sciany, podane jako 4 kolejne rogi. */
    private static void faceOutline(VertexConsumer buffer, Matrix4f matrix, float r, float g, float b, float a,
                                     double x1, double y1, double z1,
                                     double x2, double y2, double z2,
                                     double x3, double y3, double z3,
                                     double x4, double y4, double z4) {
        line(buffer, matrix, r, g, b, a, x1, y1, z1, x2, y2, z2);
        line(buffer, matrix, r, g, b, a, x2, y2, z2, x3, y3, z3);
        line(buffer, matrix, r, g, b, a, x3, y3, z3, x4, y4, z4);
        line(buffer, matrix, r, g, b, a, x4, y4, z4, x1, y1, z1);
    }

    private static void line(VertexConsumer buffer, Matrix4f matrix, float r, float g, float b, float a,
                              double x1, double y1, double z1, double x2, double y2, double z2) {
        buffer.vertex(matrix, (float) x1, (float) y1, (float) z1).color(r, g, b, a);
        buffer.vertex(matrix, (float) x2, (float) y2, (float) z2).color(r, g, b, a);
    }
}
