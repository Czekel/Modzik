package com.mediviallike.houses;

import com.mediviallike.houses.item.BlueprintItem;
import com.mediviallike.houses.schematic.BlockEntry;
import com.mediviallike.houses.schematic.Schematic;
import com.mediviallike.houses.schematic.SchematicLoader;
import com.mediviallike.houses.schematic.SchematicRotation;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Renderuje "hologram" - widmowy zarys budynku pod stopami/przed graczem,
 * gdy trzyma on Blueprint w rece. Pokazuje ksztalt budynku ZANIM zostanie
 * postawiony plac budowy, zeby latwiej wycelowac miejsce.
 *
 * Kazdy blok rysowany jest jako polprzezroczysta wypelniona bryla (nie
 * tylko cienkie linie obrysu) - dzieki temu latwiej odczytac ksztalt
 * przy wiekszych budynkach.
 *
 * Uwaga: to jest kod dzialajacy tylko po stronie klienta (rysowanie),
 * nie zmienia niczego w swiecie gry.
 */
public class MedievalHousesClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::renderGhostPreview);
    }

    private void renderGhostPreview(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }

        ItemStack mainHand = client.player.getStackInHand(Hand.MAIN_HAND);
        if (!(mainHand.getItem() instanceof BlueprintItem blueprintItem)) {
            return;
        }

        if (!(client.crosshairTarget instanceof BlockHitResult hitResult)) {
            return;
        }

        BlockPos clickedPos = hitResult.getBlockPos();
        Direction side = hitResult.getSide();
        BlockPos placePos = side == Direction.UP ? clickedPos.up() : clickedPos.offset(side);

        Schematic schematic = SchematicLoader.get(blueprintItem.getSchematicId());
        if (schematic == null) {
            return;
        }

        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        if (matrices == null || consumers == null) {
            return;
        }
        Vec3d camera = context.camera().getPos();
        VertexConsumer fillBuffer = consumers.getBuffer(RenderLayer.getDebugQuads());
        VertexConsumer lineBuffer = consumers.getBuffer(RenderLayer.getLines());

        int rotation = BlueprintItem.getRotation(mainHand);

        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        for (BlockEntry rawEntry : schematic.blocks) {
            BlockEntry entry = SchematicRotation.rotate(rawEntry, rotation);
            BlockPos targetPos = placePos.add(entry.x, entry.y, entry.z);
            Box box = new Box(targetPos);
            drawFilledBox(matrices, fillBuffer, box, 0.3f, 0.75f, 1.0f, 0.28f);
            WorldRenderer.drawBox(matrices, lineBuffer, box, 0.3f, 0.75f, 1.0f, 0.6f);
        }

        matrices.pop();
    }

    /** Rysuje 6 wypelnionych, polprzezroczystych scian prostopadloscianu. */
    private static void drawFilledBox(MatrixStack matrices, VertexConsumer buffer, Box box,
                                       float r, float g, float b, float a) {
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        float x1 = (float) box.minX, y1 = (float) box.minY, z1 = (float) box.minZ;
        float x2 = (float) box.maxX, y2 = (float) box.maxY, z2 = (float) box.maxZ;

        // dol
        quad(buffer, matrix, r, g, b, a,
                x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2);
        // gora
        quad(buffer, matrix, r, g, b, a,
                x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1);
        // polnoc (z1)
        quad(buffer, matrix, r, g, b, a,
                x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1);
        // poludnie (z2)
        quad(buffer, matrix, r, g, b, a,
                x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2);
        // zachod (x1)
        quad(buffer, matrix, r, g, b, a,
                x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1);
        // wschod (x2)
        quad(buffer, matrix, r, g, b, a,
                x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2);
    }

    private static void quad(VertexConsumer buffer, Matrix4f matrix, float r, float g, float b, float a,
                              float x1, float y1, float z1,
                              float x2, float y2, float z2,
                              float x3, float y3, float z3,
                              float x4, float y4, float z4) {
        buffer.vertex(matrix, x1, y1, z1).color(r, g, b, a);
        buffer.vertex(matrix, x2, y2, z2).color(r, g, b, a);
        buffer.vertex(matrix, x3, y3, z3).color(r, g, b, a);
        buffer.vertex(matrix, x4, y4, z4).color(r, g, b, a);
    }
}
