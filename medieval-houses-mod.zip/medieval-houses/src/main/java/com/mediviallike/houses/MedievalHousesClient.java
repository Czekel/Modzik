package com.mediviallike.houses;

import com.mediviallike.houses.block.StrawBedBlock;
import com.mediviallike.houses.item.BlueprintItem;
import com.mediviallike.houses.schematic.BlockEntry;
import com.mediviallike.houses.schematic.Schematic;
import com.mediviallike.houses.schematic.SchematicLoader;
import com.mediviallike.houses.schematic.SchematicRotation;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.HashSet;
import java.util.Set;

/**
 * Renderuje "hologram" - widmowy ZARYS BRYLY budynku (nie siatke
 * pojedynczych kratek) przed postawieniem placu budowy. Rysuje tylko
 * krawedzie scian, ktore sa "na zewnatrz" calej budowli (czyli tam,
 * gdzie w schemacie nie ma sasiedniego bloku) - dzieki temu widac
 * faktyczny ksztalt konstrukcji, a nie osobny szescian na kazdy blok.
 *
 * Uwaga: to jest kod dzialajacy tylko po stronie klienta (rysowanie),
 * nie zmienia niczego w swiecie gry.
 */
public class MedievalHousesClient implements ClientModInitializer {

    private static long sleepStartMillis = -1;
    private static boolean sneakReleased = true;
    private static final long CROUCH_DELAY_MS = 500;
    private static final long FADE_IN_MS = 700;
    private static final long HOLD_MS = 900;
    private static final long FADE_OUT_MS = 700;
    private static final long TOTAL_SLEEP_MS = CROUCH_DELAY_MS + FADE_IN_MS + HOLD_MS + FADE_OUT_MS;

    @Override
    public void onInitializeClient() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::renderGhostPreview);

        // Klikniecie w slomiane poslanie noca -> gracz przykuca (jak przy
        // "kladzeniu sie"), potem ekran sie zaciemnia i rozjasnia z powrotem.
        // Czysto kosmetyczny efekt po stronie klienta; faktyczne przewiniecie
        // czasu robi serwer w StrawBedBlock.onUse.
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.isClient || hand != Hand.MAIN_HAND) {
                return ActionResult.PASS;
            }
            BlockPos pos = hitResult.getBlockPos();
            if (!(world.getBlockState(pos).getBlock() instanceof StrawBedBlock)) {
                return ActionResult.PASS;
            }
            long time = world.getTimeOfDay() % 24000L;
            boolean isNight = time >= 12542L && time <= 23458L;
            if (isNight) {
                sleepStartMillis = System.currentTimeMillis();
                sneakReleased = false;
                player.setSneaking(true);
            }
            return ActionResult.PASS;
        });

        HudRenderCallback.EVENT.register(this::renderSleepFade);
    }

    private void renderSleepFade(DrawContext drawContext, Object tickCounter) {
        if (sleepStartMillis < 0) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        long elapsed = System.currentTimeMillis() - sleepStartMillis;

        if (elapsed > TOTAL_SLEEP_MS) {
            sleepStartMillis = -1;
            return;
        }

        // Faza kucania - jeszcze bez zaciemnienia, gracz "sie klad zie"
        if (elapsed < CROUCH_DELAY_MS) {
            return;
        }

        long fadeElapsed = elapsed - CROUCH_DELAY_MS;
        float alpha;
        if (fadeElapsed < FADE_IN_MS) {
            alpha = fadeElapsed / (float) FADE_IN_MS;
        } else if (fadeElapsed < FADE_IN_MS + HOLD_MS) {
            alpha = 1.0f;
        } else {
            alpha = 1.0f - (fadeElapsed - FADE_IN_MS - HOLD_MS) / (float) FADE_OUT_MS;
        }

        // Gdy ekran juz calkiem czarny, wstajemy z kucania (i tak niewidoczne)
        if (!sneakReleased && fadeElapsed >= FADE_IN_MS) {
            if (client.player != null) {
                client.player.setSneaking(false);
            }
            sneakReleased = true;
        }

        int width = client.getWindow().getScaledWidth();
        int height = client.getWindow().getScaledHeight();
        int argb = ((int) (alpha * 255) << 24);
        drawContext.fill(0, 0, width, height, argb);
    }

    private void renderGhostPreview(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }

        ItemStack mainHand = client.player.getStackInHand(Hand.MAIN_HAND);
        if (!(mainHand.getItem() instanceof BlueprintItem blueprintItem)) {
            return;
        }

        if (!(client.crosshairTarget instanceof BlockHitResult hitResult)) {
            return;
        }

        BlockPos clickedPos = hitResult.getBlockPos();
        Direction side = hitResult.getSide();
        BlockPos placePos = side == Direction.UP ? clickedPos.up() : clickedPos.offset(side);

        Schematic schematic = SchematicLoader.get(blueprintItem.getSchematicId());
        if (schematic == null) {
            return;
        }

        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        if (matrices == null || consumers == null) {
            return;
        }
        Vec3d camera = context.camera().getPos();
        VertexConsumer buffer = consumers.getBuffer(RenderLayer.getLines());

        int rotation = BlueprintItem.getRotation(mainHand);

        // Zbior zajetych pozycji wzglednych (po obrocie) - do sprawdzania
        // sasiadow, zeby wiedziec ktore sciany sa "na zewnatrz".
        Set<BlockPos> occupied = new HashSet<>();
        for (BlockEntry rawEntry : schematic.blocks) {
            BlockEntry entry = SchematicRotation.rotate(rawEntry, rotation);
            occupied.add(new BlockPos(entry.x, entry.y, entry.z));
        }

        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        float r = 0.3f, g = 0.75f, b = 1.0f, a = 0.85f;

        for (BlockPos rel : occupied) {
            double bx = placePos.getX() + rel.getX();
            double by = placePos.getY() + rel.getY();
            double bz = placePos.getZ() + rel.getZ();

            if (!occupied.contains(rel.down())) {
                faceOutline(buffer, matrix, r, g, b, a,
                        bx, by, bz, bx + 1, by, bz, bx + 1, by, bz + 1, bx, by, bz + 1);
            }
            if (!occupied.contains(rel.up())) {
                faceOutline(buffer, matrix, r, g, b, a,
                        bx, by + 1, bz, bx, by + 1, bz + 1, bx + 1, by + 1, bz + 1, bx + 1, by + 1, bz);
            }
            if (!occupied.contains(rel.north())) {
                faceOutline(buffer, matrix, r, g, b, a,
                        bx, by, bz, bx, by + 1, bz, bx + 1, by + 1, bz, bx + 1, by, bz);
            }
            if (!occupied.contains(rel.south())) {
                faceOutline(buffer, matrix, r, g, b, a,
                        bx, by, bz + 1, bx + 1, by, bz + 1, bx + 1, by + 1, bz + 1, bx, by + 1, bz + 1);
            }
            if (!occupied.contains(rel.west())) {
                faceOutline(buffer, matrix, r, g, b, a,
                        bx, by, bz, bx, by, bz + 1, bx, by + 1, bz + 1, bx, by + 1, bz);
            }
            if (!occupied.contains(rel.east())) {
                faceOutline(buffer, matrix, r, g, b, a,
                        bx + 1, by, bz, bx + 1, by + 1, bz, bx + 1, by + 1, bz + 1, bx + 1, by, bz + 1);
            }
        }

        matrices.pop();
    }

    /** Rysuje 4 krawedzie (obrys) jednej sciany, podane jako 4 kolejne rogi. */
    private static void faceOutline(VertexConsumer buffer, Matrix4f matrix, float r, float g, float b, float a,
                                     double x1, double y1, double z1,
                                     double x2, double y2, double z2,
                                     double x3, double y3, double z3,
                                     double x4, double y4, double z4) {
        line(buffer, matrix, r, g, b, a, x1, y1, z1, x2, y2, z2);
        line(buffer, matrix, r, g, b, a, x2, y2, z2, x3, y3, z3);
        line(buffer, matrix, r, g, b, a, x3, y3, z3, x4, y4, z4);
        line(buffer, matrix, r, g, b, a, x4, y4, z4, x1, y1, z1);
    }

    private static void line(VertexConsumer buffer, Matrix4f matrix, float r, float g, float b, float a,
                              double x1, double y1, double z1, double x2, double y2, double z2) {
        float nx = (float) (x2 - x1);
        float ny = (float) (y2 - y1);
        float nz = (float) (z2 - z1);
        buffer.vertex(matrix, (float) x1, (float) y1, (float) z1).color(r, g, b, a).normal(nx, ny, nz);
        buffer.vertex(matrix, (float) x2, (float) y2, (float) z2).color(r, g, b, a).normal(nx, ny, nz);
    }
}
