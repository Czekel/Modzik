package com.mediviallike.houses;

import com.mediviallike.houses.item.BlueprintItem;
import com.mediviallike.houses.schematic.BlockEntry;
import com.mediviallike.houses.schematic.Schematic;
import com.mediviallike.houses.schematic.SchematicLoader;
import com.mediviallike.houses.schematic.SchematicRotation;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Renderuje "hologram" - widmowy zarys budynku pod stopami/przed graczem,
 * gdy trzyma on Blueprint w rece. Pokazuje ksztalt budynku ZANIM zostanie
 * postawiony plac budowy, zeby latwiej wycelowac miejsce.
 *
 * Uwaga: to jest kod dzialajacy tylko po stronie klienta (rysowanie),
 * nie zmienia niczego w swiecie gry.
 */
public class MedievalHousesClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::renderGhostPreview);
    }

    private void renderGhostPreview(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }

        ItemStack mainHand = client.player.getStackInHand(Hand.MAIN_HAND);
        if (!(mainHand.getItem() instanceof BlueprintItem blueprintItem)) {
            return;
        }

        if (!(client.crosshairTarget instanceof BlockHitResult hitResult)) {
            return;
        }

        BlockPos clickedPos = hitResult.getBlockPos();
        Direction side = hitResult.getSide();
        BlockPos placePos = side == Direction.UP ? clickedPos.up() : clickedPos.offset(side);

        Schematic schematic = SchematicLoader.get(blueprintItem.getSchematicId());
        if (schematic == null) {
            return;
        }

        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        if (matrices == null || consumers == null) {
            return;
        }
        Vec3d camera = context.camera().getPos();
        VertexConsumer buffer = consumers.getBuffer(RenderLayer.getLines());

        int rotation = BlueprintItem.getRotation(mainHand);

        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        for (BlockEntry rawEntry : schematic.blocks) {
            BlockEntry entry = SchematicRotation.rotate(rawEntry, rotation);
            BlockPos targetPos = placePos.add(entry.x, entry.y, entry.z);
            Box box = new Box(targetPos);
            WorldRenderer.drawBox(matrices, buffer, box, 0.3f, 0.75f, 1.0f, 0.6f);
        }

        matrices.pop();
    }
}
