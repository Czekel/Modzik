package com.mediviallike.houses.block.entity;

import com.mediviallike.houses.schematic.BlockEntry;
import com.mediviallike.houses.schematic.Schematic;
import com.mediviallike.houses.schematic.SchematicLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Plac budowy - przechowuje post\u0119p budowy jednego domu:
 * jakie materia\u0142y zosta\u0142y ju\u017c dostarczone, oraz w kt\u00f3rym miejscu
 * schematu jeste\u015bmy podczas stopniowego stawiania blok\u00f3w.
 */
public class ConstructionSiteBlockEntity extends BlockEntity {

    /** Ile blok\u00f3w schematu stawiamy przy ka\u017cdym "kroku" budowy. */
    private static final int BLOCKS_PER_STEP = 3;
    /** Co ile ticków wykonujemy krok budowy (20 ticków = 1 sekunda). */
    private static final int TICKS_PER_STEP = 10;

    private String schematicId = "";
    private final Map<String, Integer> deposited = new LinkedHashMap<>();
    private int placeIndex = 0;
    private boolean building = false;
    private int tickCounter = 0;
    private String pendingSelfBlock = null;

    public ConstructionSiteBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CONSTRUCTION_SITE, pos, state);
    }

    /** Wywo\u0142ywane raz, gdy plac budowy jest stawiany przez Blueprint. */
    public void setSchematic(String schematicId) {
        this.schematicId = schematicId;
        this.deposited.clear();
        this.placeIndex = 0;
        this.building = false;
        Schematic schem = SchematicLoader.get(schematicId);
        if (schem != null) {
            for (String key : schem.materials.keySet()) {
                deposited.put(key, 0);
            }
        }
        markDirty();
    }

    /**
     * Pr\u00f3buje przyj\u0105\u0107 materia\u0142 trzymany przez gracza. Zwraca true,
     * je\u015bli co\u015b zosta\u0142o przyj\u0119te (nawet cz\u0119\u015b\u0107 stacka).
     */
    public boolean tryDeposit(PlayerEntity player, ItemStack stack) {
        Schematic schem = SchematicLoader.get(schematicId);
        if (schem == null) {
            player.sendMessage(Text.literal("\u00a7cTen plac budowy nie ma poprawnego planu."), true);
            return false;
        }
        if (building) {
            player.sendMessage(Text.literal("\u00a7eMateria\u0142y skompletowane - budowa w toku."), true);
            return false;
        }
        if (stack.isEmpty()) {
            player.sendMessage(Text.literal("\u00a77We\u017a do r\u0119ki materia\u0142 potrzebny do budowy."), true);
            return false;
        }

        Identifier itemId = Registries.ITEM.getId(stack.getItem());
        String itemKey = itemId.toString();
        Integer required = schem.materials.get(itemKey);
        if (required == null) {
            player.sendMessage(Text.literal("\u00a77Ten materia\u0142 nie jest potrzebny do: " + schem.name), true);
            return false;
        }

        int have = deposited.getOrDefault(itemKey, 0);
        if (have >= required) {
            player.sendMessage(Text.literal("\u00a7aWystarczaj\u0105co tego materia\u0142u."), true);
            return false;
        }

        int needed = required - have;
        int toTake = Math.min(needed, stack.getCount());
        stack.decrement(toTake);
        deposited.put(itemKey, have + toTake);
        markDirty();

        sendProgress(player, schem);
        checkReadyToBuild(schem);
        return true;
    }

    private void sendProgress(PlayerEntity player, Schematic schem) {
        StringBuilder sb = new StringBuilder();
        boolean complete = true;
        for (Map.Entry<String, Integer> entry : schem.materials.entrySet()) {
            int have = deposited.getOrDefault(entry.getKey(), 0);
            int need = entry.getValue();
            if (have < need) {
                complete = false;
            }
            String shortName = entry.getKey().contains(":")
                    ? entry.getKey().substring(entry.getKey().indexOf(':') + 1)
                    : entry.getKey();
            if (sb.length() > 0) {
                sb.append("  ");
            }
            sb.append(shortName).append(": ").append(have).append("/").append(need);
        }
        if (!complete) {
            player.sendMessage(Text.literal("\u00a76" + sb), true);
        }
    }

    private void checkReadyToBuild(Schematic schem) {
        for (Map.Entry<String, Integer> entry : schem.materials.entrySet()) {
            int have = deposited.getOrDefault(entry.getKey(), 0);
            if (have < entry.getValue()) {
                return;
            }
        }
        building = true;
        placeIndex = 0;
        markDirty();
    }

    public static void serverTick(World world, BlockPos pos, BlockState state, ConstructionSiteBlockEntity be) {
        if (world.isClient || !be.building) {
            return;
        }
        be.tickCounter++;
        if (be.tickCounter < TICKS_PER_STEP) {
            return;
        }
        be.tickCounter = 0;

        Schematic schem = SchematicLoader.get(be.schematicId);
        if (schem == null) {
            return;
        }
        List<BlockEntry> blocks = schem.blocks;

        int placedThisStep = 0;
        while (be.placeIndex < blocks.size() && placedThisStep < BLOCKS_PER_STEP) {
            BlockEntry entry = blocks.get(be.placeIndex);
            be.placeIndex++;

            if (entry.x == 0 && entry.y == 0 && entry.z == 0) {
                // Pozycja samego placu budowy - zapisujemy na koniec,
                // \u017ceby nie usun\u0105\u0107 tego block entity w trakcie budowy.
                be.pendingSelfBlock = entry.block;
                continue;
            }

            Block blockToPlace = resolveBlock(entry.block);
            BlockPos targetPos = pos.add(entry.x, entry.y, entry.z);
            world.setBlockState(targetPos, blockToPlace.getDefaultState(), Block.NOTIFY_ALL);
            placedThisStep++;
        }

        be.markDirty();

        if (be.placeIndex >= blocks.size()) {
            String selfBlockId = be.pendingSelfBlock != null ? be.pendingSelfBlock : "minecraft:oak_planks";
            Block selfBlock = resolveBlock(selfBlockId);
            // To zast\u0119puje blok placu budowy - ko\u0144czy istnienie tego block entity.
            world.setBlockState(pos, selfBlock.getDefaultState(), Block.NOTIFY_ALL);
        }
    }

    private static Block resolveBlock(String id) {
        Identifier identifier = Identifier.tryParse(id);
        if (identifier == null) {
            return net.minecraft.block.Blocks.AIR;
        }
        return Registries.BLOCK.get(identifier);
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.writeNbt(nbt, registryLookup);
        nbt.putString("SchematicId", schematicId);
        nbt.putBoolean("Building", building);
        nbt.putInt("PlaceIndex", placeIndex);
        if (pendingSelfBlock != null) {
            nbt.putString("PendingSelfBlock", pendingSelfBlock);
        }
        NbtCompound depositedNbt = new NbtCompound();
        deposited.forEach(depositedNbt::putInt);
        nbt.put("Deposited", depositedNbt);
    }

    @Override
    public void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.readNbt(nbt, registryLookup);
        schematicId = nbt.getString("SchematicId");
        building = nbt.getBoolean("Building");
        placeIndex = nbt.getInt("PlaceIndex");
        pendingSelfBlock = nbt.contains("PendingSelfBlock") ? nbt.getString("PendingSelfBlock") : null;
        deposited.clear();
        NbtCompound depositedNbt = nbt.getCompound("Deposited");
        for (String key : depositedNbt.getKeys()) {
            deposited.put(key, depositedNbt.getInt(key));
        }
    }
}
