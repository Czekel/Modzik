package com.mediviallike.houses.block.entity;

import com.mediviallike.houses.schematic.BlockEntry;
import com.mediviallike.houses.schematic.Schematic;
import com.mediviallike.houses.schematic.SchematicLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.state.property.Property;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Plac budowy - przechowuje postep budowy jednego domu:
 * jakie materialy zostaly juz dostarczone, oraz w ktorym miejscu
 * schematu jestesmy podczas stawiania blokow (jeden blok na klikniecie).
 */
public class ConstructionSiteBlockEntity extends BlockEntity {

    private String schematicId = "";
    private final Map<String, Integer> deposited = new LinkedHashMap<>();
    private int placeIndex = 0;
    private boolean building = false;
    private String pendingSelfBlock = null;

    public ConstructionSiteBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CONSTRUCTION_SITE, pos, state);
    }

    /** Wywolywane raz, gdy plac budowy jest stawiany przez Blueprint. */
    public void setSchematic(String schematicId) {
        this.schematicId = schematicId;
        this.deposited.clear();
        this.placeIndex = 0;
        this.building = false;
        Schematic schem = SchematicLoader.get(schematicId);
        if (schem != null) {
            for (String key : schem.materials.keySet()) {
                deposited.put(key, 0);
            }
        }
        markDirty();
    }

    public boolean isBuilding() {
        return building;
    }

    public String getSchematicId() {
        return schematicId;
    }

    /**
     * Probuje przyjac material trzymany przez gracza. Zwraca true,
     * jesli cos zostalo przyjete (nawet czesc stacka).
     */
    public boolean tryDeposit(PlayerEntity player, ItemStack stack) {
        Schematic schem = SchematicLoader.get(schematicId);
        if (schem == null) {
            player.sendMessage(Text.literal("\u00a7cTen plac budowy nie ma poprawnego planu."), true);
            return false;
        }
        if (building) {
            player.sendMessage(Text.literal("\u00a7eMaterialy skompletowane - kliknij ponownie, zeby postawic kolejny blok."), true);
            return false;
        }
        if (stack.isEmpty()) {
            player.sendMessage(Text.literal("\u00a77Wez do reki material potrzebny do budowy."), true);
            return false;
        }

        Identifier itemId = Registries.ITEM.getId(stack.getItem());
        String itemKey = itemId.toString();
        Integer required = schem.materials.get(itemKey);
        if (required == null) {
            player.sendMessage(Text.literal("\u00a77Ten material nie jest potrzebny do: " + schem.name), true);
            return false;
        }

        int have = deposited.getOrDefault(itemKey, 0);
        if (have >= required) {
            player.sendMessage(Text.literal("\u00a7aWystarczajaco tego materialu."), true);
            return false;
        }

        int needed = required - have;
        int toTake = Math.min(needed, stack.getCount());
        stack.decrement(toTake);
        deposited.put(itemKey, have + toTake);
        markDirty();

        sendProgress(player, schem);
        checkReadyToBuild(schem);
        return true;
    }

    private void sendProgress(PlayerEntity player, Schematic schem) {
        StringBuilder sb = new StringBuilder();
        boolean complete = true;
        for (Map.Entry<String, Integer> entry : schem.materials.entrySet()) {
            int have = deposited.getOrDefault(entry.getKey(), 0);
            int need = entry.getValue();
            if (have < need) {
                complete = false;
            }
            String shortName = entry.getKey().contains(":")
                    ? entry.getKey().substring(entry.getKey().indexOf(':') + 1)
                    : entry.getKey();
            if (sb.length() > 0) {
                sb.append("  ");
            }
            sb.append(shortName).append(": ").append(have).append("/").append(need);
        }
        if (!complete) {
            player.sendMessage(Text.literal("\u00a76" + sb), true);
        }
    }

    private void checkReadyToBuild(Schematic schem) {
        for (Map.Entry<String, Integer> entry : schem.materials.entrySet()) {
            int have = deposited.getOrDefault(entry.getKey(), 0);
            if (have < entry.getValue()) {
                return;
            }
        }
        building = true;
        placeIndex = 0;
        markDirty();
    }

    /**
     * Stawia dokladnie JEDEN kolejny blok schematu (wywolywane przy
     * kazdym kliknieciu PPM, gdy materialy sa juz skompletowane).
     * Zwraca true, jesli cos sie wydarzylo (blok postawiony albo
     * budowa zakonczona).
     */
    public boolean advanceBuild(World world, BlockPos pos, PlayerEntity player) {
        if (!building) {
            return false;
        }
        Schematic schem = SchematicLoader.get(schematicId);
        if (schem == null) {
            return false;
        }
        List<BlockEntry> blocks = schem.blocks;

        while (placeIndex < blocks.size()) {
            BlockEntry entry = blocks.get(placeIndex);
            placeIndex++;

            if (entry.x == 0 && entry.y == 0 && entry.z == 0) {
                // Pozycja samego placu budowy - stawiamy na koncu,
                // zeby nie usunac tego block entity w trakcie budowy.
                pendingSelfBlock = entry.block;
                continue;
            }

            BlockState stateToPlace = resolveState(entry);
            BlockPos targetPos = pos.add(entry.x, entry.y, entry.z);
            world.setBlockState(targetPos, stateToPlace, Block.NOTIFY_ALL);
            markDirty();

            int total = blocks.size();
            player.sendMessage(Text.literal("\u00a7aPostawiono blok (" + placeIndex + "/" + total + ")"), true);
            return true;
        }

        // Lista wyczerpana - stawiamy finalny blok w miejscu placu budowy.
        String selfBlockId = pendingSelfBlock != null ? pendingSelfBlock : "minecraft:oak_planks";
        BlockState selfState = resolveState(new BlockEntry(0, 0, 0, selfBlockId));
        world.setBlockState(pos, selfState, Block.NOTIFY_ALL);
        player.sendMessage(Text.literal("\u00a7aBudynek gotowy: " + schem.name + "!"), false);
        return true;
    }

    private static BlockState resolveState(BlockEntry entry) {
        Block block = resolveBlock(entry.block);
        BlockState state = block.getDefaultState();
        if (entry.state != null) {
            for (Map.Entry<String, String> prop : entry.state.entrySet()) {
                state = applyProperty(state, block, prop.getKey(), prop.getValue());
            }
        }
        return state;
    }

    private static <T extends Comparable<T>> BlockState applyProperty(BlockState state, Block block, String name, String value) {
        Property<T> property = (Property<T>) block.getStateManager().getProperty(name);
        if (property == null) {
            return state;
        }
        Optional<T> parsed = property.parse(value);
        return parsed.map(v -> state.with(property, v)).orElse(state);
    }

    private static Block resolveBlock(String id) {
        Identifier identifier = Identifier.tryParse(id);
        if (identifier == null) {
            return net.minecraft.block.Blocks.AIR;
        }
        return Registries.BLOCK.get(identifier);
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.writeNbt(nbt, registryLookup);
        nbt.putString("SchematicId", schematicId);
        nbt.putBoolean("Building", building);
        nbt.putInt("PlaceIndex", placeIndex);
        if (pendingSelfBlock != null) {
            nbt.putString("PendingSelfBlock", pendingSelfBlock);
        }
        NbtCompound depositedNbt = new NbtCompound();
        deposited.forEach(depositedNbt::putInt);
        nbt.put("Deposited", depositedNbt);
    }

    @Override
    public void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.readNbt(nbt, registryLookup);
        schematicId = nbt.getString("SchematicId");
        building = nbt.getBoolean("Building");
        placeIndex = nbt.getInt("PlaceIndex");
        pendingSelfBlock = nbt.contains("PendingSelfBlock") ? nbt.getString("PendingSelfBlock") : null;
        deposited.clear();
        NbtCompound depositedNbt = nbt.getCompound("Deposited");
        for (String key : depositedNbt.getKeys()) {
            deposited.put(key, depositedNbt.getInt(key));
        }
    }
}
