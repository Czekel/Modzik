# Medieval Houses (Fabric 1.21.1)

Mod inspirowany systemem budowania z Medieval Dynasty:
**Plan budowy** → **Plac budowy** → donosisz materiały → stawiasz dom
**blok po bloku** (jedno kliknięcie = jeden blok), z podglądem "widmowym"
(hologramem) przed postawieniem.

Świadomie tylko **3 budynki na razie** — trzy chaty (mała/średnia/duża) —
zamiast rozmieniać się na dużo budynków naraz, żeby te trzy faktycznie
były dopracowane.

## Budynki

- **"Plan: Mała chata"** (`blueprint_mala_chata`) — 5x5, murki (rogi z
  murkowych kłód, reszta z desek), okna (otwory, bez szyb), dach z kalenicą
  ze słomianych schodków. W środku (nie liczą się do materiałów):
  **słomiane posłanie, podwójna skrzynia, ognisko**. Fundament, drzwi
  i schodek przy wejściu też za darmo.
- **"Plan: Średnia chata"** (`blueprint_srednia_chata`) — ten sam układ,
  9x5 (szerokość x głębokość).
- **"Plan: Duża chata"** (`blueprint_duza_chata`) — 11x5, ściany z
  **kamiennego murku** (własny blok, drobne kamyczki), rogi nadal
  z murkowych kłód.

## Obrót planu przed postawieniem

Trzymając Blueprint, **Shift + PPM w powietrzu** (bez celowania w blok)
obraca plan o 90° — kliknij kilka razy żeby dojść do 180°/270°. Aktualny
obrót widać zarówno w komunikacie na czacie, jak i w hologramie podglądu.
Zwykłe PPM na ziemię stawia plac budowy z aktualnie wybranym obrotem.

Schematy to zwykłe pliki JSON w `src/main/resources/schematics/` — łatwo
dopisać kolejny bez grzebania w Javie (patrz niżej).

## Jak to działa

1. Trzymając Blueprint w ręce, widzisz **niebieski widmowy zarys**
   (hologram, linie) budynku tam, gdzie celujesz.
2. Klikasz PPM na ziemię → powstaje Plac budowy.
3. Donosisz materiały (trzymasz w ręce, klikasz PPM na plac) — pasek
   pokazuje postęp.
4. Gdy materiały skompletowane: **każde kolejne kliknięcie PPM na plac
   stawia dokładnie jeden kolejny blok budynku** — Ty decydujesz o tempie.

## Jak zbudować i uruchomić

Przez GitHub Actions (workflow już masz w repo) albo lokalnie:
`./gradlew build` (JDK 21 + internet wymagane).

## Jak dodać kolejny budynek

1. Nowy plik JSON w `src/main/resources/schematics/`:
   ```json
   {
     "id": "twoj_dom",
     "name": "Nazwa do wyświetlenia",
     "materials": { "minecraft:cobblestone": 64 },
     "blocks": [
       { "x": 0, "y": 0, "z": 0, "block": "minecraft:cobblestone" },
       { "x": 1, "y": 0, "z": 0, "block": "minecraft:oak_stairs",
         "state": { "facing": "north", "half": "bottom" } }
     ]
   }
   ```
   Pole `"state"` jest opcjonalne — używaj go dla bloków z orientacją
   (schody, drzwi itp.).
2. Dopisz nazwę pliku do `SchematicLoader.SCHEMATIC_FILES`.
3. Zarejestruj nowy `BlueprintItem` w `ModItems`.
4. Dodaj model itemowy (`models/item/twoj_plan.json`) i teksturę ikony.

## Nowe bloki

- **Mała kłoda** (`medieval_houses:small_log`) — łączący się murek,
  tekstura `oak_log`.
- **Słomiane schody** (`medieval_houses:straw_stairs`) — schody wyglądające
  jak siano.
- **Murek z desek** (`medieval_houses:plank_railing`) — łączący się murek,
  tekstura desek.
- **Kamienny murek** (`medieval_houses:stone_railing`) — łączący się murek,
  własna tekstura drobnych kamyczków.
- **Koryto** (`medieval_houses:trough`) — magazynek na paszę/ziarno:
  trzymając coś w ręce, klikasz PPM żeby wsypać; pustą ręką klikasz, żeby
  wyjąć. Wizualnie pokazuje czy jest pełne. **Uwaga:** to tylko
  magazynek — zwierzęta same nie podchodzą jeść, to osobny, większy temat.
- **Słomiane posłanie** (`medieval_houses:straw_bed`) — 2 bloki (jak
  normalne łóżko), trwałe (nie da się zniszczyć), bez animacji leżenia.
  Kliknięte w nocy/burzy przewija czas do rana — postać najpierw przykuca,
  potem ekran się zaciemnia i rozjaśnia z powrotem.

## Co dalej

- Kolejne budynki — dopiero gdy te trzy chaty będą naprawdę dopracowane.
- Prawdziwe GUI zamiast trzymania materiału w ręce.
- Wymóg bliskości skrzyni z materiałami zamiast trzymania w ręce.
