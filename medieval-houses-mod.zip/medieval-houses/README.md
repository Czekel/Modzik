# Medieval Houses (Fabric 1.21.1)

Mod inspirowany systemem budowania z Medieval Dynasty:
**Plan budowy** → **Plac budowy** → donosisz materiały → stawiasz dom
**blok po bloku** (jedno kliknięcie = jeden blok), z podglądem "widmowym"
(hologramem) przed postawieniem.

## Budynki (v0.2)

- **"Plan: Chata drewniana"** (`blueprint_wooden_hut`) — dom 5x5, parterowy
  (2 bloki wysokości ścian), okna, dach dwuspadowy ze schodków, w środku
  **łóżko**. Materiały: 96x `oak_planks`, 8x `oak_log`, 2x `glass_pane`,
  2x `red_bed`, 30x `oak_stairs`.
- **"Plan: Studnia"** (`blueprint_studnia`) — mała studnia 3x3 z daszkiem
  i **ogniskiem** tuż obok. Materiały: 8x `cobblestone`, 8x `spruce_fence`,
  9x `spruce_planks`, 1x `campfire`.
- **"Plan: Spichlerz"** (`blueprint_spichlerz`) — otwarta z przodu szopa
  gospodarcza 3x4, w środku **piec**. Materiały: 34x `spruce_planks`,
  4x `spruce_log`, 1x `furnace`.
- **"Plan: Chata myśliwska"** (`blueprint_chata_mysliwska`) — kamienna
  podstawa (nie liczy się do materiałów), ściany z murków: rogi z murkowych
  kłód, reszta z murków z desek, drzwi na środku frontu ze schodkiem
  (nie liczą się do materiałów), piętrowy piramidalny dach ze słomianych
  schodków. Materiały: 12x `small_log`, 34x `plank_railing`,
  48x `straw_stairs`, 36x `hay_block`, 1x `oak_stairs` (schodek).

## Obrót planu przed postawieniem

Trzymając Blueprint, **Shift + PPM w powietrzu** (bez celowania w blok)
obraca plan o 90° — kliknij kilka razy żeby dojść do 180°/270°. Aktualny
obrót widać zarówno w komunikacie na czacie, jak i w hologramie podglądu.
Zwykłe PPM na ziemię stawia plac budowy z aktualnie wybranym obrotem.

Schematy to zwykłe pliki JSON w `src/main/resources/schematics/` — łatwo
dopisać kolejne budynki bez grzebania w Javie (patrz niżej).

## Jak to działa teraz

1. Trzymając Blueprint w ręce, widzisz **niebieski widmowy zarys**
   (hologram) budynku tam, gdzie celujesz — to podgląd przed postawieniem.
   *(Uwaga: to nowa, nietestowana część kodu — jeśli hologram się nie
   wyświetli albo wysypie build, wyślij mi błąd kompilatora, poprawię.)*
2. Klikasz PPM na ziemię → powstaje Plac budowy.
3. Donosisz materiały (trzymasz w ręce, klikasz PPM na plac) — pasek
   pokazuje postęp.
4. Gdy materiały skompletowane: **każde kolejne kliknięcie PPM na plac
   stawia dokładnie jeden kolejny blok budynku** (już nie samo się buduje
   w czasie — Ty decydujesz o tempie).

## Jak zbudować i uruchomić

Jak poprzednio — przez GitHub Actions (workflow już masz w repo) albo
lokalnie: `./gradlew build` (JDK 21 + internet wymagane).

## Jak dodać kolejny budynek

1. Nowy plik JSON w `src/main/resources/schematics/`:
   ```json
   {
     "id": "twoj_dom",
     "name": "Nazwa do wyświetlenia",
     "materials": { "minecraft:cobblestone": 64 },
     "blocks": [
       { "x": 0, "y": 0, "z": 0, "block": "minecraft:cobblestone" },
       { "x": 1, "y": 0, "z": 0, "block": "minecraft:oak_stairs",
         "state": { "facing": "north", "half": "bottom" } }
     ]
   }
   ```
   Pole `"state"` jest opcjonalne — używaj go dla bloków z orientacją
   (schody, drzwi itp.).
2. Dopisz nazwę pliku do `SchematicLoader.SCHEMATIC_FILES`.
3. Zarejestruj nowy `BlueprintItem` w `ModItems`.
4. Dodaj model itemowy (`models/item/twoj_plan.json`) i teksturę ikony.

## Nowe bloki (v0.3)

- **Mała kłoda** (`medieval_houses:small_log`) — połowa wysokości zwykłej
  kłody, ta sama oryginalna tekstura `oak_log`.
- **Słomiane schody** (`medieval_houses:straw_stairs`) — normalne schody,
  ale wyglądają jak siano (tekstura `hay_block`).
- **Murek z desek** (`medieval_houses:plank_railing`) — cienki, jednolity
  słupek na całą wysokość bloku (bez grubszych "zakończeń" jak w
  wanilijnym `wall`), naturalnie równa się z futryną drzwi.
- **Koryto** (`medieval_houses:trough`) — magazynek na paszę/ziarno:
  trzymając coś w ręce, klikasz PPM żeby wsypać; pustą ręką klikasz, żeby
  wyjąć. **Uwaga:** to tylko magazynek — zwierzęta same nie podchodzą
  jeść ani znosić jajek, to wymagałoby własnej AI stworzeń (osobny,
  większy temat na później).

## Co dalej (pomysły na kolejne etapy)

- Więcej budynków z MD: stajnia, kuźnia, dom murowany (tier 2/3), studnia
  z żurawiem.
- Prawdziwe GUI zamiast trzymania materiału w ręce.
- Obracanie budynku przed postawieniem (rotacja o 90°/180°/270°).
- Wymóg bliskości skrzyni z materiałami zamiast trzymania w ręce.
