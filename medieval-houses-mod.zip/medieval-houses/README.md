# Medieval Houses (Fabric 1.21.1)

Pierwszy kawałek moda inspirowanego systemem budowania z Medieval Dynasty:
**Plan budowy** → **Plac budowy** → donosisz materiały → dom rośnie sam,
etapami, w czasie rzeczywistym.

## Co jest w środku (v0.1)

- Przedmiot **"Plan: Chata drewniana"** (`medieval_houses:blueprint_wooden_hut`)
  — kliknij PPM na ziemi, żeby postawić plac budowy.
- Blok **"Plac budowy"** (`medieval_houses:construction_site`) — trzymając w
  ręce potrzebny materiał, kliknij PPM na plac, żeby go zdeponować. Pasek nad
  paskiem doświadczenia pokazuje postęp (np. `oak_planks: 12/48`).
- Gdy wszystkie materiały są skompletowane, plac zaczyna **stawiać dom
  automatycznie**, kilka bloków co pół sekundy, aż budowa jest gotowa.
- Jeden gotowy budynek na start: **Chata drewniana** (5x5, dębowe belki i
  deski, dach z siana). Wymaga: 48x `oak_planks`, 8x `oak_log`,
  49x `hay_block`.

Schemat budynku to zwykły plik JSON w
`src/main/resources/schematics/wooden_hut.json` — łatwo dodać kolejne domy
bez grzebania w kodzie Javy (patrz niżej).

## Jak zbudować i uruchomić

Potrzebujesz: JDK 21, oraz internetu (Gradle musi pobrać Minecraft, mapowania
Yarn i Fabric API przy pierwszym uruchomieniu).

```bash
cd medieval-houses
./gradlew build          # zbuduje plik .jar w build/libs/
./gradlew runClient       # albo od razu odpal klienta testowego z modem
```

Jeśli nie masz `gradlew` (wrappera) w tym archiwum — otwórz projekt w
IntelliJ IDEA z zainstalowanym pluginem Fabric/Loom, on sam go dogeneruje,
albo doinstaluj Gradle 8.x i wpisz `gradle wrapper` w folderze projektu.

## Jak zagrać

1. `/give @s medieval_houses:blueprint_wooden_hut`
2. Znajdź płaskie miejsce, kliknij PPM na ziemi — pojawi się plac budowy.
3. Weź do ręki dębowe deski (`oak_planks`) i kliknij PPM na plac budowy,
   powtarzaj z `oak_log` i `hay_block`, aż licznik pokaże 100%.
4. Odejdź na chwilę i wróć — chata sama się postawi.

## Jak dodać kolejny budynek

1. Dodaj nowy plik JSON w `src/main/resources/schematics/`, w formacie:
   ```json
   {
     "id": "twoj_dom",
     "name": "Nazwa do wyświetlenia",
     "materials": { "minecraft:cobblestone": 64 },
     "blocks": [ { "x": 0, "y": 0, "z": 0, "block": "minecraft:cobblestone" } ]
   }
   ```
   (`x,y,z` = pozycja względem placu budowy, `0,0,0` to sam plac — ten wpis
   jest zawsze stawiany na końcu, żeby nie przerwać budowy w połowie).
2. Dopisz nazwę pliku do `SchematicLoader.SCHEMATIC_FILES`.
3. Zarejestruj nowy `BlueprintItem` w `ModItems` (skopiuj wzorzec
   `BLUEPRINT_WOODEN_HUT`, zmień `schematicId` i ścieżkę rejestracji).
4. Dodaj mu model itemowy (`models/item/twoj_dom.json`) i teksturę ikony.

## Co dalej (pomysły na kolejne etapy)

- Prawdziwe GUI (ekran z siatką potrzebnych materiałów) zamiast trzymania
  jednego materiału naraz w ręce.
- Podgląd "widmowy" (ghost outline) budynku przed postawieniem placu.
- Więcej budynków: spichlerz, stodoła, dom murowany — różne tiery jak w MD.
- Wymóg bliskości skrzyni z materiałami zamiast trzymania w ręce.
